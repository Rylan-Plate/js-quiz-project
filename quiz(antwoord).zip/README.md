# Quiz Project - Door Rylan Plate


Een quiz die je kan gebruiken om je Fortnite kennis te testen met 5 vragen!
Het is een multiple choice quiz, dat betekent dat je maximaal 4 keuzes krijgt en 1 van die keuzes klikt als antwoord.
